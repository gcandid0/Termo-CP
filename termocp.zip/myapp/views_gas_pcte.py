from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.core.exceptions import ValidationError
from math import log
import json
from . import estados as std

# Inicializa instância de gas
if not hasattr(std, 'instancia_gas'):
    std.instancia_gas = std.gas_cls()

gas = std.instancia_gas

# Garante lista_gas
if not hasattr(gas, 'lista_gas') or gas.lista_gas is None:
    gas.lista_gas = []

from .forms import (
    ConstantesPCte8, ConstantesPCte8_2,
    Prop1PCte8, Prop1PCte8_2, Prop2PCte8, TvizGasIdeal8
)

# Funções Auxiliares para conversão de temperatura
def to_kelvin(T):
    return T + 273.15 if T is not None else None

def to_celsius(T):
    return T - 273.15 if T is not None else None

def rd(x):
    return round(x, 4) if x is not None else None

###############################################################################
# VIEWS DE FORMULÁRIO
###############################################################################

def ask_known1_view8(request):
    try:
        gas.limpar_gas()
    except Exception:
        gas.lista_gas = []

    request.session['lista_gas'] = json.dumps(gas.lista_gas, default=str)

    # ==========================================================
    # GARANTIA DE LIMPEZA DO GRÁFICO AO INICIAR NOVO CICLO
    # ==========================================================
    request.session['pontos_grafico'] = []
    request.session['historico_processos'] = []
    if 'dados_processo' in request.session:
        del request.session['dados_processo']
    if hasattr(gas, 'pontos_grafico_gas'):
        gas.pontos_grafico_gas.clear()
    # ==========================================================

    if request.method == 'POST':
        form = ConstantesPCte8(request.POST)
        if form.is_valid():
            request.session['property_choice'] = int(form.cleaned_data['property_choice'])
            request.session['value_input'] = float(form.cleaned_data['value_input'])
            return redirect('ask_known2_8')
    else:
        form = ConstantesPCte8()
    return render(request, 'gas/ask_known1_8.html', {'form': form})

def ask_known2_view8(request):
    prop = request.session.get('property_choice')
    excluded = [str(prop)] if prop is not None else []

    if request.method == 'POST':
        form = ConstantesPCte8_2(request.POST, excluded_properties=excluded)
        if form.is_valid():
            second_property_choice = int(form.cleaned_data['property_choice'])
            second_value_input = float(form.cleaned_data['value_input'])

            # Validação de Constantes
            const1 = int(request.session.get('property_choice'))
            val1 = float(request.session.get('value_input'))
            const_values = {const1: val1, second_property_choice: second_value_input}

            Cv0 = const_values.get(11)
            Cp0 = const_values.get(12)
            R = const_values.get(13)
            K = const_values.get(14)

            # Lógica de determinação cruzada
            if Cp0 is not None and Cv0 is not None:
                R = Cp0 - Cv0
                K = Cp0 / Cv0 if Cv0 else None
            elif Cp0 is not None and R is not None:
                Cv0 = Cp0 - R
                K = Cp0 / Cv0 if Cv0 else None
            elif Cv0 is not None and R is not None:
                Cp0 = Cv0 + R
                K = Cp0 / Cv0 if Cv0 else None
            elif R is not None and K is not None:
                if K != 1:
                    Cv0 = R / (K - 1)
                    Cp0 = K * Cv0

            error_messages = []
            if R is not None and R <= 0: error_messages.append("R deve ser positivo.")
            if K is not None and K <= 1: error_messages.append("K deve ser maior que 1.")

            if error_messages:
                context = {"Cv0": Cv0, "Cp0": Cp0, "R": R, "K": K, "error_messages": error_messages}
                return render(request, "error_constants.html", context)

            request.session['second_property_choice'] = second_property_choice
            request.session['second_value_input'] = second_value_input
            return redirect('ask_known3_8')
    else:
        form = ConstantesPCte8_2(excluded_properties=excluded)
    return render(request, 'gas/ask_known2_8.html', {'form': form})

def ask_known3_view8(request):
    # Primeira propriedade do Estado 1: usuário escolhe livremente entre T, p ou v
    if request.method == 'POST':
        form = Prop1PCte8(request.POST)
        if form.is_valid():
            request.session['state1_property_choice_1'] = str(form.cleaned_data['property_choice'])
            request.session['state1_value_input_1'] = float(form.cleaned_data['value_input'])
            return redirect('ask_known4_8')
    else:
        form = Prop1PCte8()
    return render(request, 'gas/ask_known3_8.html', {'form': form})

def ask_known4_view8(request):
    # Segunda propriedade do Estado 1: exclui a já escolhida na etapa anterior
    first = request.session.get('state1_property_choice_1')
    excluded_properties = [str(first)] if first is not None else []

    if request.method == 'POST':
        form = Prop1PCte8_2(request.POST, excluded_properties=excluded_properties)
        if form.is_valid():
            request.session['state1_property_choice_2'] = str(form.cleaned_data['property_choice'])
            request.session['state1_value_input_2'] = float(form.cleaned_data['value_input'])
            return redirect('ask_known5_8')
    else:
        form = Prop1PCte8_2(excluded_properties=excluded_properties)
    return render(request, 'gas/ask_known4_8.html', {'form': form})

def ask_known5_view8(request):
    if request.method == 'POST':
        form = Prop2PCte8(request.POST)
        if form.is_valid():
            request.session['four_property_choice'] = int(form.cleaned_data['property_choice'])
            request.session['four_value_input'] = float(form.cleaned_data['value_input'])
            return redirect('ask_known6_8')
    else:
        form = Prop2PCte8()
    return render(request, 'gas/ask_known5_8.html', {'form': form})

def ask_known6_view8(request):
    if request.method == 'POST':
        form = TvizGasIdeal8(request.POST)
        if form.is_valid():
            request.session['Tviz_value_input'] = float(form.cleaned_data['Tviz_value_input'])
            return redirect('process_values_8')
    else:
        form = TvizGasIdeal8()
    return render(request, 'gas/ask_known6_8.html', {'form': form})

###############################################################################
# CÁLCULOS FINAIS (PRESSÃO CONSTANTE)
###############################################################################

def process_values_view8(request):
    try:
        # =====================================
        # 0️⃣ Ressincroniza a lista de estados com a SESSÃO do usuário atual
        # =====================================
        # IMPORTANTE: `gas` é uma instância única compartilhada no módulo (via
        # `std.instancia_gas`), reaproveitada por TODOS os processos de gás e
        # TODAS as requisições. Sem este passo, `gas.lista_gas` pode conter o
        # estado deixado por outro usuário ou por outro tipo de processo
        # (isotérmico, isocórico, politrópico, etc.), fazendo o relatório final
        # exibir mais "Estados" do que processos realmente calculados nesta sessão.
        if 'lista_gas' not in request.session:
            request.session['lista_gas'] = json.dumps([])
        try:
            gas.lista_gas = json.loads(request.session['lista_gas'])
        except Exception:
            gas.lista_gas = []

        # =====================================
        # 1️⃣ Recupera dados da sessão
        # =====================================
        Tviz_input = float(request.session.get('Tviz_value_input'))

        c1_idx = int(request.session.get('property_choice'))
        c1_val = float(request.session.get('value_input'))
        c2_idx = int(request.session.get('second_property_choice'))
        c2_val = float(request.session.get('second_value_input'))

        prop2_idx = int(request.session.get('four_property_choice'))
        prop2_val = float(request.session.get('four_value_input'))

        # =====================================
        # 2️⃣ Determinação das Constantes
        # =====================================
        map_const = {c1_idx: c1_val, c2_idx: c2_val}

        Cv0 = map_const.get(11)
        Cp0 = map_const.get(12)
        R = map_const.get(13)
        K = map_const.get(14)

        if Cp0 is not None and Cv0 is not None:
            R = Cp0 - Cv0
            K = Cp0 / Cv0 if Cv0 != 0 else None
        elif Cp0 is not None and R is not None:
            Cv0 = Cp0 - R
            K = Cp0 / Cv0 if Cv0 != 0 else None
        elif Cv0 is not None and R is not None:
            Cp0 = Cv0 + R
            K = Cp0 / Cv0 if Cv0 != 0 else None
        elif R is not None and K is not None:
            Cv0 = R / (K - 1)
            Cp0 = K * Cv0

        if R is None or Cp0 is None:
            return redirect('error_type8')

        # =====================================
        # 3️⃣ ESTADO 1 (INICIAL)
        # =====================================

        if gas.lista_gas:
            # Usa SEMPRE o último estado salvo
            ultimo = gas.lista_gas[-1]

            # Estrutura: [Cv, Cp, R, K, p, T_C, v]
            p1 = float(ultimo[4])
            T1 = to_kelvin(float(ultimo[5])) # Kelvin
            v1 = float(ultimo[6])
        else:
            # Primeiro processo: Estado 1 definido por 2 propriedades livres (T, p ou v)
            s1p1 = int(request.session.get('state1_property_choice_1'))
            s1v1 = float(request.session.get('state1_value_input_1'))
            s1p2 = int(request.session.get('state1_property_choice_2'))
            s1v2 = float(request.session.get('state1_value_input_2'))

            T1 = p1 = v1 = None
            for prop, val in [(s1p1, s1v1), (s1p2, s1v2)]:
                if prop == 0:    # Temperatura (°C -> K)
                    T1 = to_kelvin(val)
                elif prop == 1:  # Pressão
                    p1 = val
                elif prop == 2:  # Volume específico
                    v1 = val

            try:
                # Equação de estado do gás ideal: p*v = R*T
                if T1 is None: T1 = (p1 * v1) / R
                if p1 is None: p1 = (R * T1) / v1
                if v1 is None: v1 = (R * T1) / p1
            except (TypeError, ZeroDivisionError):
                return redirect('error_type8')

            if T1 is None or p1 is None or v1 is None:
                return redirect('error_type8')

        # =====================================
        # 4️⃣ ESTADO 2 (FINAL)
        # =====================================

        p2 = p1  # PRESSÃO CONSTANTE
        Q12_input = None

        if prop2_idx == 0:  # T fornecido (em °C, converte para K)
            T2 = to_kelvin(prop2_val)
            v2 = (R * T2) / p2

        elif prop2_idx == 2:  # v fornecido
            v2 = prop2_val
            T2 = (p2 * v2) / R # Resultado direto em Kelvin

        elif prop2_idx == 8:  # Q fornecido
            Q12_input = prop2_val
            # T1 já está em Kelvin, o aumento em Kelvin é igual ao aumento em Celsius
            T2 = T1 + (Q12_input / Cp0)
            v2 = (R * T2) / p2

        else:
            return redirect('error_type8')

        if T1 is None or T2 is None or T1 <= 0 or T2 <= 0:
            return redirect('error_type8')

        # =====================================
        # 5️⃣ CÁLCULOS DO PROCESSO
        # =====================================

        W12 = p1 * (v2 - v1)

        if Q12_input is not None:
            Q12 = Q12_input
        else:
            # T2 e T1 em Kelvin, Cp0 em kJ/kgK
            Q12 = Cp0 * (T2 - T1)

        Tviz_K = to_kelvin(Tviz_input)

        try:
            # Entropia calculada sempre com temperaturas em KELVIN
            delta_S = Cp0 * log(T2 / T1)
            Sger = delta_S - (Q12 / Tviz_K)
        except ValueError:
            Sger = None

        # ==========================================================
        # GERAÇÃO DE MICROPROCESSOS PARA O DIAGRAMA (GÁS IDEAL)
        # ==========================================================
        pontos_grafico = request.session.get('pontos_grafico', [])

        num_passos = 150
        passo_T = (T2 - T1) / num_passos if T1 != T2 else 0

        # Funções teóricas para o gráfico (Ref: 25°C / 298.15 K e 100 kPa)
        def calc_h(T_K): return Cp0 * (T_K - 298.15)
        def calc_s(T_K, P_kPa):
            if T_K <= 0 or P_kPa <= 0: return 0
            return Cp0 * log(T_K / 298.15) - R * log(P_kPa / 100)

        ramo_atual = []

        # Ponto Inicial
        ramo_atual.append({
            'T': round(to_celsius(T1), 2),
            'P': round(p1, 2),
            'v': round(v1, 6),
            's': round(calc_s(T1, p1), 4),
            'h': round(calc_h(T1), 2)
        })

        if passo_T != 0:
            for i in range(1, num_passos):
                T_micro = T1 + (i * passo_T)
                P_micro = p1  # Processo Isobárico
                v_micro = (R * T_micro) / P_micro

                ramo_atual.append({
                    'T': round(to_celsius(T_micro), 2),
                    'P': round(P_micro, 2),
                    'v': round(v_micro, 6),
                    's': round(calc_s(T_micro, P_micro), 4),
                    'h': round(calc_h(T_micro), 2)
                })

        # Ponto Final
        ramo_atual.append({
            'T': round(to_celsius(T2), 2),
            'P': round(p2, 2),
            'v': round(v2, 6),
            's': round(calc_s(T2, p2), 4),
            'h': round(calc_h(T2), 2)
        })

        pontos_grafico.append(ramo_atual)
        request.session['pontos_grafico'] = pontos_grafico

        # Sincroniza com a classe gas
        if hasattr(gas, 'pontos_grafico_gas'):
            gas.pontos_grafico_gas = pontos_grafico

        # Não permitir pressão ou volume negativos
        if p1 < 0.0001 or v1 < 0.0001 or p2 < 0.0001 or v2 < 0.0001:
            return redirect('error_type7')

        if v1 > 1000 or v2 > 1000:
            return redirect('error_type7')
        # ==========================================================

        # =====================================
        # 6️⃣ SALVAR NOVO ESTADO E GERAR CONTEXTO
        # =====================================

        T2_C = to_celsius(T2) # Converte de volta para salvar na lista

        novo_estado = [
            float(Cv0),
            float(Cp0),
            float(R),
            float(K) if K else 0.0,
            float(p2),
            float(T2_C),
            float(v2)
        ]

        gas.lista_gas.append(novo_estado)
        request.session['lista_gas'] = json.dumps(gas.lista_gas, default=str)

        # =====================================
        # 6️⃣.1 HISTÓRICO DE PROCESSOS (para o Relatório Final)
        # =====================================
        historico_processos = request.session.get('historico_processos', [])
        historico_processos.append({
            'TempViz': rd(Tviz_input),
            'Q': rd(Q12),
            'W': rd(W12),
            'Sger': rd(Sger),
        })
        request.session['historico_processos'] = historico_processos

        context = {
            'Cv0': rd(Cv0),
            'Cp0': rd(Cp0),
            'R': rd(R),
            'K': rd(K),
            'p': rd(p1),
            'T1': rd(to_celsius(T1)), # Exibe em °C
            'T2': rd(T2_C), # Exibe em °C
            'v1': rd(v1),
            'v2': rd(v2),
            'Q12': rd(Q12),
            'W12': rd(W12),
            'Sger': rd(Sger),
            'Tviz': rd(Tviz_input), # Exibe original em °C
            'teste': gas.lista_gas,
            'pontos_grafico_json': json.dumps(pontos_grafico), # Dados para o Chart.js
            'historico_processos_json': json.dumps(historico_processos) # Histórico p/ Relatório Final
        }

        return render(request, 'gas/results_8.html', context)

    except Exception as e:
        print(f"Erro process_values_8: {e}")
        return redirect('error_type8')

def error_type_view8(request):
    return render(request, 'erro_generico.html')